package com.example.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Admin;
import com.example.repository.AdminRepository;
@Service
public class AdminServiceImpl implements AdminService {
	@Autowired
	AdminRepository ar1;

	@Override
	public Admin saveAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return ar1.save(admin);
	}
	@Override
    public List<Admin> fetchAdminList() {
        return ar1.findAll();
    }

   @Override
   public Admin fetchAdminById(Long adminId) {
	   return ar1.findById(adminId).get();
   }
	
   @Override
   public void deleteAdminById(Long adminId) {
       ar1.deleteById(adminId);
   }


   @Override
   public Admin updateAdmin(Long adminId, Admin admin) {
       Admin depDB = ar1.findById(adminId).get();

       if(Objects.nonNull(admin.getUsername()) &&
               !"".equalsIgnoreCase(admin.getUsername())) {
           depDB.setUsername(admin.getUsername());
       }

       if(Objects.nonNull(admin.getPassword()) &&
               !"".equalsIgnoreCase(admin.getPassword())) {
           depDB.setPassword(admin.getPassword());
       }

       return ar1.save(depDB);
   }


}
